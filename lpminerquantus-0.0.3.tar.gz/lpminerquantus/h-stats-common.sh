#!/usr/bin/env bash
# HiveOS sources this file inside /hive/bin/agent, not executes it. Set the
# caller-scope variables `khs` and `stats`. The native JSON snapshot is the
# primary source; a machine-readable log record is used only if publication
# of that snapshot failed inside lpminer.

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$script_dir/h-manifest.conf"

miner_ver="${CUSTOM_NAME}-${CUSTOM_VERSION}"
if [[ -x "$script_dir/lpminer" ]]; then
    bin_ver=$("$script_dir/lpminer" --version 2>/dev/null |
        head -1 | tr -d '\r' || true)
    if [[ $bin_ver == lpminer-* ]]; then
        miner_ver="$bin_ver"
    fi
fi

nvidia_bus_numbers_json() {
    local out="["
    local first=1
    local pci_bus
    while IFS= read -r pci_bus; do
        pci_bus=$(awk -F: '{print $2}' <<< "$pci_bus")
        [[ -z $pci_bus ]] && continue
        if [[ $first -eq 0 ]]; then
            out+=","
        fi
        if [[ $pci_bus =~ ^[0-9A-Fa-f]+$ ]]; then
            out+="$((16#$pci_bus))"
        else
            out+="0"
        fi
        first=0
    done < <(nvidia-smi --query-gpu=pci.bus_id --format=csv,noheader 2>/dev/null)
    out+="]"
    echo "$out"
}

gpu_stats_bus_numbers_json() {
    local out="["
    local first=1
    local pci_bus
    while IFS= read -r pci_bus; do
        pci_bus=$(awk -F: '{print $1}' <<< "$pci_bus")
        [[ -z $pci_bus ]] && continue
        if [[ $first -eq 0 ]]; then
            out+=","
        fi
        if [[ $pci_bus =~ ^[0-9A-Fa-f]+$ ]]; then
            out+="$((16#$pci_bus))"
        else
            out+="0"
        fi
        first=0
    done < <(jq -r '.busids[]? // empty' <<< "${gpu_stats:-}" 2>/dev/null)
    out+="]"
    echo "$out"
}

align_stats_to_gpu_slots() {
    [[ -z ${gpu_stats:-} || -z ${stats:-} || $stats == "null" ]] && return
    local full_bus temp fan
    full_bus=$(gpu_stats_bus_numbers_json)
    [[ $full_bus == "[]" ]] && return
    temp=$(jq -c '.temp // []' <<< "$gpu_stats" 2>/dev/null)
    fan=$(jq -c '.fan // []' <<< "$gpu_stats" 2>/dev/null)
    stats=$(jq -c \
        --argjson full_bus "$full_bus" \
        --argjson temp "$temp" \
        --argjson fan "$fan" \
        '
        (.bus_numbers // []) as $src_bus |
        (.hs // []) as $src_hs |
        .hs = ($full_bus | map(. as $b |
            ($src_bus | index($b)) as $idx |
            if $idx == null then 0 else ($src_hs[$idx] // 0) end
        )) |
        .bus_numbers = $full_bus |
        .temp = $temp |
        .fan = $fan
        ' <<< "$stats" 2>/dev/null)
}

canonical_hive_algo() {
    local value="${1,,}"
    case "$value" in
        mochimo|peach) echo "peach" ;;
        c29|cuckaroo29) echo "c29" ;;
        csd|sha256d-csd) echo "sha256d-csd" ;;
        alphanumeric|blake3-an) echo "blake3-an" ;;
        quantus|poseidon2-goldilocks) echo "poseidon2-goldilocks" ;;
        pearl) echo "pearl" ;;
        *) echo "$value" ;;
    esac
}

configured_hive_algo() {
    local value="${LP_HIVE_EXPECTED_ALGO:-}"
    local config_file="${LP_HIVE_CONFIG_FILE:-${MINER_CONFIG_FILENAME:-}}"
    local config=""
    if [[ -z $value && -n $config_file && -r $config_file ]]; then
        config=$(tr '\n' ' ' < "$config_file" 2>/dev/null)
        if [[ $config =~ (^|[[:space:]])--algo=([^[:space:];]+) ]]; then
            value="${BASH_REMATCH[2]}"
        elif [[ $config =~ (^|[[:space:]])--algo[[:space:]]+([^[:space:];]+) ]]; then
            value="${BASH_REMATCH[2]}"
        fi
    fi
    value="${value#\"}"
    value="${value%\"}"
    value="${value#\'}"
    value="${value%\'}"
    canonical_hive_algo "$value"
}

snapshot_is_fresh() {
    local timestamp="${1:-}"
    local fallback_path="${2:-}"
    local now
    if [[ ! $timestamp =~ ^[0-9]{1,12}$ && -n $fallback_path && -e $fallback_path ]]; then
        timestamp=$(stat -c %Y "$fallback_path" 2>/dev/null)
    fi
    [[ $timestamp =~ ^[0-9]{1,12}$ ]] || return 1
    now=$(date +%s)
    [[ $now =~ ^[0-9]{1,12}$ ]] || return 1
    timestamp=$((10#$timestamp))
    now=$((10#$now))
    (( timestamp <= now + 5 && now - timestamp <= hive_stats_max_age ))
}

collect_stats_logs() {
    stats_logs=()
    local basename="${LP_HIVE_LOG_BASENAME:-${CUSTOM_LOG_BASENAME}}"
    local file
    for file in "${basename}".log "${basename}"-gpu*.log; do
        [[ -f $file ]] && stats_logs+=("$file")
    done
    if [[ ${#stats_logs[@]} -eq 0 &&
          -z ${LP_HIVE_LOG_BASENAME:-} &&
          -f /root/lpminer-pearl.screen.log ]]; then
        stats_logs+=(/root/lpminer-pearl.screen.log)
    fi
}

fallback_hardware_arrays() {
    local device_csv="$1"
    local -a devices
    local device temp fan pci_bus
    local first=1
    fallback_temps_json="["
    fallback_fans_json="["
    fallback_bus_json="["
    IFS=',' read -ra devices <<< "$device_csv"
    for device in "${devices[@]}"; do
        temp=$(nvidia-smi -i "$device" --query-gpu=temperature.gpu \
            --format=csv,noheader,nounits 2>/dev/null | head -1 | tr -d ' ')
        fan=$(nvidia-smi -i "$device" --query-gpu=fan.speed \
            --format=csv,noheader,nounits 2>/dev/null | head -1 | tr -d ' ')
        pci_bus=$(nvidia-smi -i "$device" --query-gpu=pci.bus_id \
            --format=csv,noheader 2>/dev/null | head -1 | awk -F: '{print $2}')
        [[ $temp =~ ^[0-9]+$ ]] || temp=0
        [[ $fan =~ ^[0-9]+$ ]] || fan=0
        if [[ $first -eq 0 ]]; then
            fallback_temps_json+=","
            fallback_fans_json+=","
            fallback_bus_json+=","
        fi
        fallback_temps_json+="$temp"
        fallback_fans_json+="$fan"
        if [[ $pci_bus =~ ^[0-9A-Fa-f]+$ ]]; then
            fallback_bus_json+="$((16#$pci_bus))"
        else
            fallback_bus_json+="$device"
        fi
        first=0
    done
    fallback_temps_json+="]"
    fallback_fans_json+="]"
    fallback_bus_json+="]"
}

read_generic_fallback() {
    local best_line=""
    local best_timestamp=0
    local file candidate candidate_timestamp
    for file in "${stats_logs[@]}"; do
        candidate=$(perl -pe 's/\e\[[0-9;]*[A-Za-z]//g; s/\r$//' \
            "$file" 2>/dev/null | grep 'stats-fallback:' | tail -1)
        [[ -z $candidate ]] && continue
        candidate_timestamp=$(sed -n \
            's/.*stats-fallback: timestamp=\([0-9][0-9]*\) .*/\1/p' \
            <<< "$candidate")
        snapshot_is_fresh "$candidate_timestamp" || continue
        if (( 10#$candidate_timestamp > best_timestamp )); then
            best_timestamp=$((10#$candidate_timestamp))
            best_line="$candidate"
        fi
    done
    [[ -n $best_line ]] || return 1

    local fallback_algo device_csv hs_csv accepted rejected uptime
    fallback_algo=$(sed -n 's/.* algo=\([^ ]*\) .*/\1/p' <<< "$best_line")
    device_csv=$(sed -n 's/.* device_ids=\([^ ]*\) .*/\1/p' <<< "$best_line")
    hs_csv=$(sed -n 's/.* hs_khs=\([^ ]*\) .*/\1/p' <<< "$best_line")
    accepted=$(sed -n 's/.* accepted=\([0-9][0-9]*\) .*/\1/p' <<< "$best_line")
    rejected=$(sed -n 's/.* rejected=\([0-9][0-9]*\) .*/\1/p' <<< "$best_line")
    uptime=$(sed -n 's/.* uptime=\([0-9][0-9]*\).*/\1/p' <<< "$best_line")
    fallback_algo=$(canonical_hive_algo "$fallback_algo")

    [[ -n $fallback_algo ]] || return 1
    [[ $device_csv =~ ^[0-9]+(,[0-9]+)*$ ]] || return 1
    [[ $hs_csv =~ ^[0-9]+([.][0-9]+)?(,[0-9]+([.][0-9]+)?)*$ ]] || return 1
    [[ $accepted =~ ^[0-9]+$ && $rejected =~ ^[0-9]+$ && $uptime =~ ^[0-9]+$ ]] || return 1
    [[ -z $expected_algo || $fallback_algo == "$expected_algo" ]] || return 1

    local hs_json="[$hs_csv]"
    local device_json="[$device_csv]"
    local hs_count device_count total_khs
    hs_count=$(jq -r 'length' <<< "$hs_json" 2>/dev/null)
    device_count=$(jq -r 'length' <<< "$device_json" 2>/dev/null)
    [[ $hs_count =~ ^[0-9]+$ && $hs_count -gt 0 && $hs_count -eq $device_count ]] || return 1
    total_khs=$(jq -r 'add // 0' <<< "$hs_json" 2>/dev/null)
    [[ -n $total_khs ]] || return 1

    fallback_hardware_arrays "$device_csv"
    stats=$(jq -nc \
        --argjson timestamp "$best_timestamp" \
        --arg algo "$fallback_algo" \
        --argjson hs "$hs_json" \
        --argjson temp "$fallback_temps_json" \
        --argjson fan "$fallback_fans_json" \
        --argjson bus "$fallback_bus_json" \
        --argjson ar "[$accepted,$rejected]" \
        --arg ver "$miner_ver" \
        --argjson total_khs "$total_khs" \
        --argjson uptime "$uptime" \
        '{schema:1,timestamp:$timestamp,hs:$hs,hs_units:"khs",total_khs:$total_khs,temp:$temp,fan:$fan,bus_numbers:$bus,ar:$ar,uptime:$uptime,ver:$ver,algo:$algo}' \
        2>/dev/null)
    [[ -n $stats ]] || return 1
    khs="$total_khs"
    return 0
}

read_legacy_pearl_fallback() {
    local hs_json="["
    local temps_json="["
    local fans_json="["
    local bus_json="["
    local accepted_total=0
    local rejected_total=0
    local sum_khs="0"
    local uptime=0
    local gpu_idx=0
    local file line tmac accepted rejected elapsed gpu_khs temp fan pci_bus

    for file in "${stats_logs[@]}"; do
        snapshot_is_fresh "" "$file" || continue
        line=$(perl -pe 's/\e\[[0-9;]*[A-Za-z]//g; s/\r$//' \
            "$file" 2>/dev/null | grep 'stratum.*stats:' | tail -1)
        [[ -z $line ]] && continue
        tmac=$(sed -n 's/.*kernel_tmac_s=\([0-9.]*\).*/\1/p' <<< "$line")
        accepted=$(sed -n 's/.* accepted=\([0-9]*\) .*/\1/p' <<< "$line")
        rejected=$(sed -n 's/.* rejected=\([0-9]*\) .*/\1/p' <<< "$line")
        elapsed=$(sed -n 's/.* elapsed=\([0-9.]*\)s .*/\1/p' <<< "$line")
        [[ -z $tmac ]] && continue
        [[ -z $accepted ]] && accepted=0
        [[ -z $rejected ]] && rejected=0
        [[ -z $elapsed ]] && elapsed=0
        gpu_khs=$(awk -v x="$tmac" 'BEGIN { printf "%.3f", x * 1000000000.0 }')

        if [[ $hs_json != "[" ]]; then
            hs_json+=","
            temps_json+=","
            fans_json+=","
            bus_json+=","
        fi
        hs_json+="$gpu_khs"
        temp=$(nvidia-smi -i "$gpu_idx" --query-gpu=temperature.gpu \
            --format=csv,noheader,nounits 2>/dev/null | head -1 | tr -d ' ')
        fan=$(nvidia-smi -i "$gpu_idx" --query-gpu=fan.speed \
            --format=csv,noheader,nounits 2>/dev/null | head -1 | tr -d ' ')
        pci_bus=$(nvidia-smi -i "$gpu_idx" --query-gpu=pci.bus_id \
            --format=csv,noheader 2>/dev/null | head -1 | awk -F: '{print $2}')
        [[ $temp =~ ^[0-9]+$ ]] || temp=0
        [[ $fan =~ ^[0-9]+$ ]] || fan=0
        temps_json+="$temp"
        fans_json+="$fan"
        if [[ $pci_bus =~ ^[0-9A-Fa-f]+$ ]]; then
            bus_json+="$((16#$pci_bus))"
        else
            bus_json+="$gpu_idx"
        fi
        accepted_total=$((accepted_total + accepted))
        rejected_total=$((rejected_total + rejected))
        sum_khs=$(awk -v a="$sum_khs" -v b="$gpu_khs" \
            'BEGIN { printf "%.3f", a + b }')
        uptime=$(awk -v a="$uptime" -v b="$elapsed" \
            'BEGIN { printf "%d", (b > a ? b : a) }')
        gpu_idx=$((gpu_idx + 1))
    done

    hs_json+="]"
    temps_json+="]"
    fans_json+="]"
    bus_json+="]"
    [[ $hs_json != "[]" ]] || return 1
    stats=$(jq -nc \
        --argjson hs "$hs_json" \
        --argjson temp "$temps_json" \
        --argjson fan "$fans_json" \
        --argjson bus "$bus_json" \
        --argjson ar "[$accepted_total,$rejected_total]" \
        --arg ver "$miner_ver" \
        --argjson total_khs "$sum_khs" \
        --argjson uptime "$uptime" \
        '{hs:$hs,hs_units:"khs",total_khs:$total_khs,temp:$temp,fan:$fan,bus_numbers:$bus,ar:$ar,uptime:$uptime,ver:$ver,algo:"pearl"}' \
        2>/dev/null)
    [[ -n $stats ]] || return 1
    khs="$sum_khs"
    return 0
}

hive_stats_max_age="${LP_HIVE_STATS_MAX_AGE_SECS:-30}"
if [[ $hive_stats_max_age =~ ^[0-9]+$ ]]; then
    hive_stats_max_age=$((10#$hive_stats_max_age))
else
    hive_stats_max_age=30
fi
if (( hive_stats_max_age < 1 || hive_stats_max_age > 3600 )); then
    hive_stats_max_age=30
fi
expected_algo=$(configured_hive_algo)
khs=0
stats="null"
native_ok=0
native_stats_file="${LP_HIVE_STATS_FILE:-/var/run/hive-miner-${CUSTOM_NAME}.stats.json}"
if [[ -s $native_stats_file ]]; then
    native_stats=$(<"$native_stats_file")
    if jq -e . >/dev/null 2>&1 <<< "$native_stats"; then
        native_schema=$(jq -r '.schema // 1' <<< "$native_stats" 2>/dev/null)
        native_timestamp=$(jq -r '.timestamp // empty' <<< "$native_stats" 2>/dev/null)
        native_algo=$(canonical_hive_algo \
            "$(jq -r '.algo // empty' <<< "$native_stats" 2>/dev/null)")
        if [[ $native_schema == "1" && -n $native_algo ]] &&
           snapshot_is_fresh "$native_timestamp" "$native_stats_file" &&
           [[ -z $expected_algo || $native_algo == "$expected_algo" ]]; then
            bus=$(nvidia_bus_numbers_json)
            stats=$(jq -c --arg ver "$miner_ver" --argjson bus "$bus" \
                '
                def hs_as_kh:
                    if (.hs_units // "khs") == "mhs" then (.hs // [] | map(. * 1000))
                    elif (.hs_units // "khs") == "hs" then (.hs // [] | map(. / 1000))
                    elif (.hs_units // "khs") == "proofs" then (.hs // [])
                    else (.hs // []) end;
                (.hs_units // "khs") as $source_units |
                .ver = $ver |
                if ((.bus_numbers // []) | length) == 0 then .bus_numbers = $bus else . end |
                .hs = hs_as_kh |
                .hs_units = "khs" |
                .total_khs = ([.hs[]?] | add // 0) |
                if $source_units == "proofs" then
                    .proofs_s = .hs |
                    .total_proofs_s = ([.proofs_s[]?] | add // 0) |
                    .rate_unit = "proof/s" |
                    .hive_compat_contract = "1 khs field unit = 1 proof/s"
                else . end
                ' <<< "$native_stats" 2>/dev/null)
            if [[ -n $stats ]]; then
                khs=$(jq -r '[.hs[]?] | add // 0' <<< "$stats" 2>/dev/null)
                khs=${khs:-0}
                native_temp_count=$(jq -r \
                    '.temp | if type == "array" then length else 0 end' \
                    <<< "$stats" 2>/dev/null)
                native_fan_count=$(jq -r \
                    '.fan | if type == "array" then length else 0 end' \
                    <<< "$stats" 2>/dev/null)
                hs_count=$(jq -r \
                    '.hs | if type == "array" then length else 0 end' \
                    <<< "$stats" 2>/dev/null)
                if [[ -n ${gpu_stats:-} &&
                      ( $native_temp_count -eq 0 || $native_fan_count -eq 0 ) ]]; then
                    temp=$(jq -c ".temp // [] | .[:$hs_count]" \
                        <<< "$gpu_stats" 2>/dev/null)
                    fan=$(jq -c ".fan // [] | .[:$hs_count]" \
                        <<< "$gpu_stats" 2>/dev/null)
                    if [[ -n $temp && -n $fan ]]; then
                        stats=$(jq -c --argjson temp "$temp" --argjson fan "$fan" \
                            '.temp = $temp | .fan = $fan' <<< "$stats" 2>/dev/null)
                    fi
                fi
                [[ -z $stats ]] && stats="null"
                [[ $stats != "null" ]] && native_ok=1
            fi
        fi
    fi
fi

if [[ $native_ok -eq 0 ]]; then
    collect_stats_logs
    if read_generic_fallback; then
        native_ok=1
    elif [[ $expected_algo == "pearl" ]] && read_legacy_pearl_fallback; then
        native_ok=1
    fi
fi

align_stats_to_gpu_slots
