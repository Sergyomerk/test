#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
. ./h-manifest.conf

export MINER_NAME CUSTOM_NAME CUSTOM_VERSION
export LP_DISABLE_HOTKEYS="${LP_DISABLE_HOTKEYS:-1}"
export LP_HIVE_STATS=1
export LP_HIVE_STATS_FILE="${LP_HIVE_STATS_FILE:-/var/run/hive-miner-${CUSTOM_NAME}.stats.json}"

if pgrep -x lpminer >/dev/null 2>&1; then
    echo "lpminer is already running" >&2
    exit 1
fi
# Compare codepoints: jq 1.6 treats contains("\u0000") as an empty-string match.
if ! jq -e 'type == "array" and length > 0 and all(.[]; type == "string" and (explode | index(0) | not))' \
        "$MINER_CONFIG_FILENAME" >/dev/null; then
    echo "Invalid or missing configuration; regenerate the HiveOS flight sheet" >&2
    exit 1
fi
mapfile -d '' -t miner_args < <(jq -j '.[] | ., "\u0000"' "$MINER_CONFIG_FILENAME")

mkdir -p /run/hive "$(dirname "$CUSTOM_LOG_BASENAME")" "$(dirname "$LP_HIVE_STATS_FILE")"
: > /run/hive/MINER_RUN
printf '%s\n' '{"status":"running"}' > /run/hive/miner_status.1
rm -f -- "$LP_HIVE_STATS_FILE"
./lpminer "${miner_args[@]}" 2>&1 | tee -a "${CUSTOM_LOG_BASENAME}.log"
