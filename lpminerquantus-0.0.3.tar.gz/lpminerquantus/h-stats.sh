#!/usr/bin/env bash
# Leave khs and stats in the HiveOS agent's caller scope.
quantus_stats_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LP_HIVE_EXPECTED_ALGO=quantus
. "$quantus_stats_dir/h-stats-common.sh"
if [[ ${stats:-null} != null ]]; then
    stats=$(jq -c --arg version "${CUSTOM_NAME}-${CUSTOM_VERSION}" \
        '.ver = $version' <<< "$stats")
fi
