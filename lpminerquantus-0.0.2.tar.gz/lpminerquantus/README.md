# lpminerquantus 0.0.2

Quantus-only NVIDIA CUDA miner for the LuckyPool Quantus Stratum protocol.

## HiveOS custom miner

- Miner name: `lpminerquantus`
- Version: `0.0.2`
- Wallet and worker template: `%WAL%.%WORKER_NAME%`
- Pool URL: your Quantus pool's `HOST:PORT`
- Password: `x` (or leave empty)
- Extra config: optional, for example `--devices 0,1` or `--param batch=2785280`

The installer archive must be served as `lpminerquantus-0.0.2.tar.gz`.
Use its actual hosted URL in HiveOS's custom miner Installation URL field.
This local package does not publish an installation URL automatically.

`h-config.sh` defaults to `--algo quantus` and generates a JSON argument array
from the flight-sheet fields. Full `--pool` / `--wallet` arguments in Extra
config override those fields. Shell quoting is supported in Extra config;
shell commands and substitutions are not executed.

For solo mining, prefix the wallet address with `solo:`. For static difficulty,
use a template such as `%WAL%=2g.%WORKER_NAME%`; the pool applies its minimum.

Config: `/hive/miners/custom/lpminerquantus/config.json`.
Log: `/var/log/miner/custom/lpminerquantus.log`.
Native stats: `/var/run/hive-miner-lpminerquantus.stats.json`.

## Direct use

```sh
./lpminer --algo quantus --pool HOST:PORT --wallet ADDRESS.WORKER --worker WORKER
./lpminer --version
./lpminer --list-combos
sha256sum -c SHA256SUMS
```

## Runtime

This archive targets NVIDIA RTX 30, 40 and 50 series, with native SASS for
SM 86, 89 and 120. Confirm the exact archive's architecture list in
`build-info.json`. The CMP build is deferred; CMP support is outside this
archive's scope.
Hardware compatibility and throughput require qualification of that archive
on each GPU model; the architecture list alone does not establish those results.

The runtime requires Linux x86-64, Ubuntu 22.04 or newer, glibc 2.35 or newer,
and an NVIDIA R580 or newer driver. ELF dependency checks and the minimum glibc
version are recorded in `build-info.json`.

The host executable and GPU images use CUDA 13.2. Local testing uses driver
595.71.05; the earlier native RTX 50 kernel was tested with 580.173.02.

HiveOS scripts need Bash, Python 3, jq, and standard procps/coreutils tools.
CUDA runtime and OpenSSL are linked statically. The C++ and GCC runtime
libraries are bundled in `lib/`; the host provides glibc and its NVIDIA driver.
Build and package locally with `tools/build-quantus-hiveos.sh`, then transfer
the finished archive to the rig for installation and execution. No CUDA toolkit
or source compilation is needed on the rig. `build-info.json` records the exact
source, build image, architecture list, and ELF dependencies. The package does
not change GPU power or clocks.
