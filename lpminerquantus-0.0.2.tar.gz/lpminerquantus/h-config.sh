#!/usr/bin/env bash
# HiveOS sources this script. Store an argv array so wallet/config text is
# never evaluated as a shell command by h-run.sh.
quantus_generate_config() {
    local package_dir config_dir
    package_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" || return
    . "$package_dir/h-manifest.conf"
    config_dir="$(dirname "$CUSTOM_CONFIG_FILENAME")"
    mkdir -p "$config_dir" || return
    if declare -F mkfile_from_symlink >/dev/null; then
        mkfile_from_symlink "$CUSTOM_CONFIG_FILENAME" || return
    fi
    CUSTOM_TEMPLATE="${CUSTOM_TEMPLATE:-}" \
    CUSTOM_URL="${CUSTOM_URL:-}" \
    CUSTOM_PASS="${CUSTOM_PASS:-}" \
    CUSTOM_USER_CONFIG="${CUSTOM_USER_CONFIG:-}" \
    WORKER_NAME="${WORKER_NAME:-lpminerquantus}" \
    python3 - "$CUSTOM_CONFIG_FILENAME" <<'PY'
import json
import os
from pathlib import Path
import shlex
import sys

try:
    args = shlex.split(os.environ["CUSTOM_USER_CONFIG"])
    def supplied(*names):
        return any(arg in names or any(arg.startswith(name + "=") for name in names)
                   for arg in args)
    def option_value(name):
        value = ""
        for index, arg in enumerate(args):
            if arg == name and index + 1 < len(args):
                value = args[index + 1]
            elif arg.startswith(name + "="):
                value = arg[len(name) + 1:]
        return value
    defaults = []
    if not supplied("--algo", "--coin"):
        defaults += ["--algo", "quantus"]
    if not supplied("--pool"):
        pool = os.environ["CUSTOM_URL"].strip()
        if not pool or any(character.isspace() for character in pool):
            raise ValueError("set one Pool URL, or supply --pool in Extra config")
        defaults += ["--pool", pool]
    if not supplied("--wallet"):
        wallet = os.environ["CUSTOM_TEMPLATE"].strip()
        if not wallet:
            raise ValueError("set Wallet and worker template, or supply --wallet in Extra config")
        defaults += ["--wallet", wallet]
    else:
        wallet = option_value("--wallet")
    if not supplied("--worker") and not wallet.partition(".")[2]:
        defaults += ["--worker", os.environ["WORKER_NAME"]]
    password = os.environ["CUSTOM_PASS"]
    if password and not supplied("--password"):
        defaults += ["--password", password]
    config = Path(sys.argv[1])
    temporary = config.with_name(config.name + ".tmp." + str(os.getpid()))
    temporary.write_text(json.dumps(defaults + args, indent=2) + "\n")
    temporary.chmod(0o600)
    temporary.replace(config)
except (ValueError, OSError) as error:
    print("lpminerquantus configuration error: " + str(error), file=sys.stderr)
    sys.exit(1)
PY
}
quantus_generate_config
