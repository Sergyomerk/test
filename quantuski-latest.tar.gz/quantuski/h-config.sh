#!/usr/bin/env bash

# HiveOS custom-miner configuration for Quantuski.

_quantuski_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=/dev/null
source "$_quantuski_dir/h-manifest.conf"

# shellcheck source=/dev/null
source "$_quantuski_dir/h-update.sh"

_quantuski_fail() {
    echo "Quantuski config error: $*" >&2
    return 1
}

_quantuski_pool_from_url() {
    local raw="$1" endpoint port had_nocasematch=0

    [[ -n "$raw" ]] || _quantuski_fail "CUSTOM_URL must contain a pool endpoint" || return 1

    shopt -q nocasematch && had_nocasematch=1
    shopt -s nocasematch
    case "$raw" in
        stratum+tcp://*) endpoint=${raw#*://} ;;
        stratum://*) endpoint=${raw#*://} ;;
        tcp://*) endpoint=${raw#*://} ;;
        stratum+ssl://*|stratum+tls://*|ssl://*|tls://*)
            (( had_nocasematch )) || shopt -u nocasematch
            _quantuski_fail "Quantuski 0.1 uses plain TCP; TLS pool URLs are not supported" || return 1
            ;;
        *://*)
            (( had_nocasematch )) || shopt -u nocasematch
            _quantuski_fail "unsupported pool URL scheme in CUSTOM_URL" || return 1
            ;;
        *) endpoint=$raw ;;
    esac
    (( had_nocasematch )) || shopt -u nocasematch

    endpoint=${endpoint%/}
    case "${endpoint,,}" in
        jetskipool.ai|www.jetskipool.ai|quantus.jetskipool.ai)
            endpoint=$QUANTUSKI_DEFAULT_POOL_ENDPOINT
            ;;
    esac
    if [[ "$endpoint" =~ ^\[[^][]+\]:([0-9]{1,5})$ ]]; then
        port=${BASH_REMATCH[1]}
    elif [[ "$endpoint" =~ ^[^:/[:space:]]+:([0-9]{1,5})$ ]]; then
        port=${BASH_REMATCH[1]}
    else
        _quantuski_fail "pool must resolve to HOST:PORT (IPv6 must use [ADDR]:PORT)" || return 1
    fi

    if (( 10#$port < 1 || 10#$port > 65535 )); then
        _quantuski_fail "pool port must be between 1 and 65535" || return 1
    fi

    QUANTUSKI_CONFIG_POOL=$endpoint
}

_quantuski_pool_selection() {
    local raw=${CUSTOM_URL:-} endpoint
    local -a endpoints=()
    local -A seen=()

    raw=${raw//$'\r'/ }
    raw=${raw//$'\n'/ }
    raw=${raw//,/ }
    raw=${raw//;/ }
    read -r -a endpoints <<< "$raw"
    ((${#endpoints[@]} > 0)) || _quantuski_fail "CUSTOM_URL must contain a pool endpoint" || return 1
    ((${#endpoints[@]} <= 32)) || _quantuski_fail "at most 32 pools are supported" || return 1

    QUANTUSKI_CONFIG_POOLS=()
    for endpoint in "${endpoints[@]}"; do
        _quantuski_pool_from_url "$endpoint" || return 1
        if [[ -n ${seen[${QUANTUSKI_CONFIG_POOL,,}]:-} ]]; then
            _quantuski_fail "duplicate pool endpoint: $QUANTUSKI_CONFIG_POOL" || return 1
        fi
        seen[${QUANTUSKI_CONFIG_POOL,,}]=1
        QUANTUSKI_CONFIG_POOLS+=("$QUANTUSKI_CONFIG_POOL")
    done
}

_quantuski_gpu_selection() {
    local -a words=()
    local value=auto user_config=${CUSTOM_USER_CONFIG:-}

    user_config=${user_config//$'\r'/ }
    user_config=${user_config//$'\n'/ }
    user_config=${user_config#"${user_config%%[![:space:]]*}"}
    user_config=${user_config%"${user_config##*[![:space:]]}"}
    if [[ -n "$user_config" ]]; then
        read -r -a words <<< "$user_config"
        case ${#words[@]} in
            1)
                if [[ "${words[0]}" == --gpus=* ]]; then
                    value=${words[0]#--gpus=}
                else
                    _quantuski_fail "extra config supports only --gpus auto|all|0,1" || return 1
                fi
                ;;
            2)
                if [[ "${words[0]}" == "--gpus" ]]; then
                    value=${words[1]}
                else
                    _quantuski_fail "extra config supports only --gpus auto|all|0,1" || return 1
                fi
                ;;
            *)
                _quantuski_fail "extra config supports only --gpus auto|all|0,1" || return 1
                ;;
        esac
    fi

    if [[ "$value" != auto && "$value" != all && ! "$value" =~ ^[0-9]+(,[0-9]+)*$ ]]; then
        _quantuski_fail "invalid --gpus value: $value" || return 1
    fi
    QUANTUSKI_CONFIG_GPUS=$value
}

_quantuski_write_config() {
    local template wallet worker config_file config_dir tmp index
    local -a args

    template=${CUSTOM_TEMPLATE:-}
    template=${template#"${template%%[![:space:]]*}"}
    template=${template%%[[:space:]]*}
    [[ -n "$template" ]] || _quantuski_fail "CUSTOM_TEMPLATE must contain a wallet" || return 1

    wallet=${template%%.*}
    if [[ "$template" == *.* ]]; then
        worker=${template#*.}
    else
        worker=${WORKER_NAME:-$(hostname -s)}
    fi
    [[ -n "$wallet" ]] || _quantuski_fail "wallet is empty" || return 1
    [[ -n "$worker" ]] || worker=$(hostname -s)

    _quantuski_pool_selection || return 1
    _quantuski_gpu_selection || return 1

    args=(--user "$wallet" --worker "$worker" --pool "${QUANTUSKI_CONFIG_POOLS[0]}" --gpus "$QUANTUSKI_CONFIG_GPUS")
    for ((index = 1; index < ${#QUANTUSKI_CONFIG_POOLS[@]}; index++)); do
        args+=("--pool$((index + 1))" "${QUANTUSKI_CONFIG_POOLS[index]}")
    done
    config_file=${CUSTOM_CONFIG_FILENAME:-$_quantuski_dir/quantuski.conf}
    config_dir=$(dirname -- "$config_file")
    mkdir -p "$config_dir" || return 1
    tmp="$config_file.tmp.$$"

    {
        printf 'QUANTUSKI_ARGS=('
        printf ' %q' "${args[@]}"
        printf ' )\n'
        # Hive sources h-config.sh, so this Flight Sheet variable may not be
        # exported to h-run.sh. Preserve it for periodic update pinning.
        printf 'QUANTUSKI_CONFIG_INSTALL_URL=%q\n' "${CUSTOM_INSTALL_URL:-}"
    } > "$tmp" || {
        rm -f "$tmp"
        return 1
    }
    if ! chmod 600 "$tmp"; then
        rm -f -- "$tmp"
        _quantuski_fail "could not secure temporary config: $tmp" || return 1
    fi
    if ! mv -f -- "$tmp" "$config_file"; then
        rm -f -- "$tmp"
        _quantuski_fail "could not install config: $config_file" || return 1
    fi

    echo "Quantuski configured for worker '$worker', pools '${QUANTUSKI_CONFIG_POOLS[*]}', GPUs '$QUANTUSKI_CONFIG_GPUS'"
}

_quantuski_check_auto_update
_quantuski_write_config
_quantuski_status=$?

unset -f _quantuski_download_update_stdout _quantuski_normalize_update_hash
unset -f _quantuski_schedule_hive_restart _quantuski_check_auto_update
unset -f _quantuski_update_owner_is_live _quantuski_watch_updates
unset -f _quantuski_fail _quantuski_pool_from_url _quantuski_pool_selection _quantuski_gpu_selection _quantuski_write_config
unset _quantuski_dir _quantuski_update_dir
return "$_quantuski_status" 2>/dev/null || exit "$_quantuski_status"
