#!/usr/bin/env bash

# Shared startup/hourly update check and launcher. The monitor stays in the
# miner's process group so h-stop.sh also stops its sleep/download children.
_quantuski_update_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)

_quantuski_download_update_stdout() {
    local url="$1"
    local connect_timeout=${QUANTUSKI_UPDATE_CONNECT_TIMEOUT_SEC:-10}
    local max_time=${QUANTUSKI_UPDATE_MAX_TIME_SEC:-30}

    if command -v curl >/dev/null 2>&1; then
        curl -fsSL \
            --connect-timeout "$connect_timeout" \
            --max-time "$max_time" \
            --retry 2 \
            "$url" 2>/dev/null
    elif command -v wget >/dev/null 2>&1; then
        wget -q \
            --connect-timeout="$connect_timeout" \
            --timeout="$max_time" \
            --tries=3 \
            -O - "$url" 2>/dev/null
    else
        return 1
    fi
}

_quantuski_normalize_update_hash() {
    awk 'NF {print $1; exit}' | tr -d '\r' | tr '[:upper:]' '[:lower:]'
}

_quantuski_schedule_hive_restart() {
    [[ "${QUANTUSKI_UPDATE_RESTART:-1}" == "0" ]] && return 0

    if command -v screen >/dev/null 2>&1 && command -v miner >/dev/null 2>&1; then
        screen -d -m miner restart 200>&-
    elif command -v miner >/dev/null 2>&1; then
        # The restart must survive termination of the miner's process group,
        # and must not retain the check lock or the miner's log pipe.
        setsid bash -c 'sleep 1; miner restart' 200>&- </dev/null >/dev/null 2>&1 &
    else
        echo "Auto-update: miner restart command not available"
    fi
}

_quantuski_update_owner_is_live() {
    # No owner is supplied for the one-off h-config.sh check.
    [[ -n ${1:-} ]] || return 0
    awk -v expected="$2" '$3 != "Z" && $22 == expected { live=1 } END { exit !live }' \
        "/proc/$1/stat" 2>/dev/null
}

_quantuski_check_auto_update() (
    local remote_hash local_hash local_file install_archive

    [[ "${QUANTUSKI_AUTO_UPDATE:-1}" == "0" ]] && return 0
    _quantuski_update_owner_is_live "$@" || return 0

    # Serialize startup and periodic checks without delaying either caller.
    # The subshell owns this descriptor; sourcing the helper cannot leak it.
    exec 200>"$_quantuski_update_dir/update.lock" || return 0
    flock -n 200 || return 0

    if [[ -n "${CUSTOM_INSTALL_URL:-}" ]]; then
        install_archive=${CUSTOM_INSTALL_URL%%\?*}
        install_archive=${install_archive##*/}
        if [[ "$install_archive" != "$QUANTUSKI_UPDATE_ARCHIVE" ]]; then
            echo "Auto-update skipped: Flight Sheet archive '$install_archive' does not match '$QUANTUSKI_UPDATE_ARCHIVE'"
            return 0
        fi
    fi

    remote_hash=$(_quantuski_download_update_stdout "$QUANTUSKI_UPDATE_HASH_URL" | _quantuski_normalize_update_hash)
    if [[ ! "$remote_hash" =~ ^[0-9a-f]{64}$ ]]; then
        echo "Auto-update skipped: no valid hash at $QUANTUSKI_UPDATE_HASH_URL"
        return 0
    fi

    local_file="${QUANTUSKI_UPDATE_LOCAL_FILE:-/hive/miners/custom/downloads/$QUANTUSKI_UPDATE_ARCHIVE}"
    if [[ ! -f "$local_file" ]]; then
        echo "Auto-update skipped: local HiveOS archive cache not found: $local_file"
        return 0
    fi

    if ! command -v sha256sum >/dev/null 2>&1; then
        echo "Auto-update skipped: sha256sum is not available"
        return 0
    fi
    local_hash=$(sha256sum "$local_file" 2>/dev/null | awk '{print $1}' | tr '[:upper:]' '[:lower:]')
    if [[ ! "$local_hash" =~ ^[0-9a-f]{64}$ ]]; then
        echo "Auto-update skipped: could not hash local archive: $local_file"
        return 0
    fi
    if [[ "$local_hash" == "$remote_hash" ]]; then
        return 0
    fi

    _quantuski_update_owner_is_live "$@" || return 0
    echo "Auto-update: cached archive differs from remote, clearing $local_file"
    if ! rm -f -- "$local_file"; then
        echo "Auto-update skipped: could not remove cached archive: $local_file"
        return 0
    fi
    echo "Auto-update: requesting HiveOS miner restart"
    _quantuski_schedule_hive_restart
)

_quantuski_watch_updates() {
    local interval=${QUANTUSKI_UPDATE_INTERVAL_SEC:-3600}

    if [[ ! "$interval" =~ ^[1-9][0-9]*$ ]]; then
        echo "Auto-update: invalid interval '$interval'; using 3600 seconds"
        interval=3600
    fi
    echo "Auto-update: checking every $interval seconds at $QUANTUSKI_UPDATE_HASH_URL"
    while sleep "$interval"; do
        _quantuski_update_owner_is_live "$@" || return 0
        echo "Auto-update: checking remote hash"
        _quantuski_check_auto_update "$@"
    done
}

# h-config.sh sources this file for the same check used by the hourly monitor.
# h-run.sh invokes --run via setsid: exec preserves the leader PID/start token
# and executable identity already used by the existing lifecycle hooks.
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
    # shellcheck source=/dev/null
    source "$_quantuski_update_dir/h-manifest.conf"
    if [[ ${1:-} != --run || $# -lt 2 ]]; then
        echo "Usage: h-update.sh --run MINER [ARGS...]" >&2
        exit 1
    fi
    shift
    if [[ "$QUANTUSKI_AUTO_UPDATE" != 0 ]]; then
        _quantuski_update_start=$(awk '{print $22}' "/proc/$$/stat")
        if [[ "$_quantuski_update_start" =~ ^[0-9]+$ ]]; then
            _quantuski_watch_updates "$$" "$_quantuski_update_start" &
        fi
    fi
    exec "$@"
fi
