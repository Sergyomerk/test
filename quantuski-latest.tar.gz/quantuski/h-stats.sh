#!/usr/bin/env bash

# Sourced by HiveOS. Always leave numeric `khs` and valid JSON (or null) in `stats`.
khs=0
stats=null

_quantuski_stats_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=/dev/null
source "$_quantuski_stats_dir/h-manifest.conf"

_quantuski_log=${QUANTUSKI_LOG_FILE:-${CUSTOM_LOG_BASENAME}.log}
_quantuski_start="$_quantuski_stats_dir/miner_start_time"
_quantuski_snapshot="$_quantuski_stats_dir/miner_latest_stats"
_quantuski_snapshot_mode="$_quantuski_stats_dir/stats_snapshot_v1"
_quantuski_generation="$_quantuski_stats_dir/capture.generation"

_quantuski_rate_to_khs() {
    local value=$1 prefix=${2:-}
    LC_ALL=C awk -v value="$value" -v prefix="$prefix" 'BEGIN {
        prefix = tolower(prefix)
        multiplier = 0.001
        if (prefix == "k") multiplier = 1
        else if (prefix == "m") multiplier = 1000
        else if (prefix == "g") multiplier = 1000000
        else if (prefix == "t") multiplier = 1000000000
        else if (prefix == "p") multiplier = 1000000000000
        else if (prefix == "e") multiplier = 1000000000000000
        # Preserve sub-kilohash rates; rounding to integers hides slow GPUs.
        rate = sprintf("%.9f", value * multiplier)
        sub(/0+$/, "", rate)
        sub(/[.]$/, "", rate)
        printf "%s", rate
    }'
}

_quantuski_join() {
    local IFS=,
    printf '%s' "$*"
}

_quantuski_parse_stats() {
    local now mtime line total_value total_prefix accepted rejected total_khs generation
    local rest token gpu value prefix idx temp fan pci bus_hex bus cuda_idx=0
    local stale_sec smi_timeout
    local uptime=0
    local had_nocasematch=0
    local -a gpu_ids=() rates=() temps=() fans=() buses=()
    local -A temp_by_gpu=() fan_by_gpu=() bus_by_gpu=()

    now=$(date +%s)
    [[ "$now" =~ ^[0-9]+$ ]] || return 0
    stale_sec=${QUANTUSKI_STATS_STALE_SEC:-120}
    [[ "$stale_sec" =~ ^[0-9]+$ ]] || stale_sec=120
    if [[ -e "$_quantuski_snapshot_mode" ]]; then
        [[ -r "$_quantuski_generation" ]] || return 0
        read -r generation < "$_quantuski_generation" 2>/dev/null || return 0
        [[ "$generation" =~ ^run-[0-9]+-[0-9]+-[0-9]+-[0-9]+$ ]] || return 0
        _quantuski_snapshot="$_quantuski_stats_dir/miner_latest_stats.$generation"
        [[ -s "$_quantuski_snapshot" ]] || return 0
        mtime=$(stat -Lc %Y "$_quantuski_snapshot" 2>/dev/null || printf '0')
        [[ "$mtime" =~ ^[0-9]+$ ]] || return 0
        (( now >= mtime && now - mtime <= stale_sec )) || return 0
        line=$(tail -n 1 "$_quantuski_snapshot" 2>/dev/null \
            | sed -E $'s/\\x1B\\[[0-9;]*[[:alpha:]]//g; s/\r$//')
    else
        # Permit parsing a standalone miner log before the wrapper's first run.
        [[ -s "$_quantuski_log" ]] || return 0
        mtime=$(stat -Lc %Y "$_quantuski_log" 2>/dev/null || printf '0')
        [[ "$mtime" =~ ^[0-9]+$ ]] || return 0
        (( now >= mtime && now - mtime <= stale_sec )) || return 0
        line=$(tail -n 2000 "$_quantuski_log" 2>/dev/null \
            | sed -E $'s/\\x1B\\[[0-9;]*[[:alpha:]]//g; s/\r$//' \
            | awk '{ lower=tolower($0) } lower ~ /gpu\[[0-9]+\]/ && lower ~ /\|[[:space:]]*a:[0-9]+[[:space:]]+r:[0-9]+/ { last=$0 } END { print last }')
    fi
    [[ -n "$line" ]] || return 0

    shopt -q nocasematch && had_nocasematch=1
    shopt -s nocasematch
    if [[ "$line" =~ ([0-9]+([.][0-9]+)?)[[:space:]]*([kmgtpe]?)h/s[[:space:]]*\|[[:space:]]*A:([0-9]+)[[:space:]]+R:([0-9]+) ]]; then
        total_value=${BASH_REMATCH[1]}
        total_prefix=${BASH_REMATCH[3]// /}
        accepted=${BASH_REMATCH[4]}
        rejected=${BASH_REMATCH[5]}
    else
        (( had_nocasematch )) || shopt -u nocasematch
        return 0
    fi

    rest=$line
    while [[ "$rest" =~ GPU\[([0-9]+)\][[:space:]]+([0-9]+([.][0-9]+)?)[[:space:]]*([kmgtpe]?)h/s ]]; do
        token=${BASH_REMATCH[0]}
        gpu=${BASH_REMATCH[1]}
        value=${BASH_REMATCH[2]}
        prefix=${BASH_REMATCH[4]}
        gpu_ids+=("$gpu")
        rates+=("$(_quantuski_rate_to_khs "$value" "$prefix")")
        rest=${rest#*"$token"}
    done
    (( had_nocasematch )) || shopt -u nocasematch
    ((${#gpu_ids[@]} > 0)) || return 0

    smi_timeout=${QUANTUSKI_NVIDIA_SMI_TIMEOUT_SEC:-5}
    [[ "$smi_timeout" =~ ^[1-9][0-9]*$ ]] || smi_timeout=5
    while IFS=, read -r idx temp fan pci; do
        idx=${idx//[[:space:]]/}
        temp=${temp//[[:space:]]/}
        fan=${fan//[[:space:]]/}
        pci=${pci//[[:space:]]/}
        [[ "$idx" =~ ^[0-9]+$ ]] || continue
        [[ "$temp" =~ ^[0-9]+$ ]] || temp=0
        [[ "$fan" =~ ^[0-9]+$ ]] || fan=0
        bus_hex=${pci#*:}
        bus_hex=${bus_hex%%:*}
        if [[ "$bus_hex" =~ ^[0-9A-Fa-f]+$ ]]; then
            bus=$((16#$bus_hex))
        else
            bus=0
        fi
        # h-run.sh uses CUDA_DEVICE_ORDER=PCI_BUS_ID. NVIDIA-SMI's own
        # indices may differ, so assign CUDA ordinals in PCI address order.
        temp_by_gpu[$cuda_idx]=$temp
        fan_by_gpu[$cuda_idx]=$fan
        bus_by_gpu[$cuda_idx]=$bus
        cuda_idx=$((cuda_idx + 1))
    done < <(
        if command -v timeout >/dev/null 2>&1 && command -v nvidia-smi >/dev/null 2>&1; then
            timeout -k 1s "${smi_timeout}s" \
                nvidia-smi \
                --query-gpu=index,temperature.gpu,fan.speed,pci.bus_id \
                --format=csv,noheader,nounits 2>/dev/null \
                | LC_ALL=C sort -t, -k4,4
        fi
    )

    for gpu in "${gpu_ids[@]}"; do
        temps+=("${temp_by_gpu[$gpu]:-0}")
        fans+=("${fan_by_gpu[$gpu]:-0}")
        buses+=("${bus_by_gpu[$gpu]:-0}")
    done

    if [[ -r "$_quantuski_start" ]]; then
        read -r mtime < "$_quantuski_start"
        [[ "$mtime" =~ ^[0-9]+$ ]] && (( now >= mtime )) && uptime=$((now - mtime))
    fi

    total_khs=$(_quantuski_rate_to_khs "$total_value" "$total_prefix")
    # Hive reads these variables after sourcing this script.
    # shellcheck disable=SC2034
    khs=$total_khs
    # shellcheck disable=SC2034
    printf -v stats '{"hs":[%s],"hs_units":"khs","temp":[%s],"fan":[%s],"uptime":%s,"ver":"%s","ar":[%s,%s],"algo":"qpow","bus_numbers":[%s]}' \
        "$(_quantuski_join "${rates[@]}")" \
        "$(_quantuski_join "${temps[@]}")" \
        "$(_quantuski_join "${fans[@]}")" \
        "$uptime" "$CUSTOM_VERSION" "$accepted" "$rejected" \
        "$(_quantuski_join "${buses[@]}")"
}

_quantuski_parse_stats
unset -f _quantuski_rate_to_khs _quantuski_join _quantuski_parse_stats
unset _quantuski_stats_dir _quantuski_log _quantuski_start
unset _quantuski_snapshot _quantuski_snapshot_mode _quantuski_generation
