
#!/usr/bin/env bash
# set -euo pipefail

cd `dirname $0`

# 读取静态路径（CUSTOM_CONFIG_FILENAME / CUSTOM_LOG_BASENAME 等）
. h-manifest.conf

# 读取 h-config.sh 生成的配置（含飞行表里的 CUSTOM_URL / CUSTOM_TEMPLATE / CUSTOM_USER_CONFIG）
[[ -f $CUSTOM_CONFIG_FILENAME ]] && . $CUSTOM_CONFIG_FILENAME

# 展开 CUSTOM_USER_CONFIG（例如取出 TOKEN）
EXPANDED_USER_CONFIG=$(eval echo "$CUSTOM_USER_CONFIG")
# set -a：把其中的 KEY=VALUE 全部自动 export，让 miner 子进程能读到（如 MINER_SUBMIT_VERSION）
set -a
eval "$CUSTOM_USER_CONFIG"
set +a

log() { printf '[%(%F %T)T] [select-miner] %s\n' -1 "$*" >&2; }
die() { log "ERROR: $*"; exit 1; }

echo "Debug CUSTOM_URL=$CUSTOM_URL CUSTOM_TEMPLATE=$CUSTOM_TEMPLATE TOKEN=$TOKEN MINER_SUBMIT_VERSION=$MINER_SUBMIT_VERSION"
echo "Debug MINER_SUBMIT_VERSION=$MINER_SUBMIT_VERSION"

# ## ───────────────────────────────────────────────
# ## 按 GPU 型号选 miner 二进制
# ## 检测失败一律 fallback 到 ./miner，不阻断启动
# ## ───────────────────────────────────────────────
# MINER_BIN=./miner   # 安全默认
#
# if ! command -v nvidia-smi >/dev/null 2>&1; then
#     log "WARN: nvidia-smi not found; using default miner"
# elif ! gpu_names="$(timeout 5 nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null)" \
#      || [ -z "$gpu_names" ]; then
#     log "WARN: nvidia-smi query failed or 0 GPUs (driver/掉卡?); using default miner"
# else
#     gpu_count=$(printf '%s\n' "$gpu_names" | grep -c .)
#     five090_count=$(printf '%s\n' "$gpu_names" | grep -ic '5090' || true)
#     five4060_count=$(printf '%s\n' "$gpu_names" | grep -ic '4060' || true)
#     log "detected ${gpu_count} GPU(s): $(printf '%s\n' "$gpu_names" | paste -sd ';' -)"
#     # ## 给 5090 使用独立二进制
#     # if [ "$five090_count" -gt 0 ]; then
#     #     [ "$five090_count" -eq "$gpu_count" ] \
#     #         || log "WARN: mixed GPUs (${five090_count}/${gpu_count} are 5090); using miner-5090"
#     #     MINER_BIN=./miner-5090
#     # fi
#
#     ## 给 4060 指定环境变量
#     if [ "$five4060_count" -gt 0 ]; then
#         export MINER_GPU_LARGE_SLOTS=1
#     fi
# fi

# =========================
# 1. 获取 CUDA 版本（优先 nvidia-smi，其次 nvcc）
#    注意：nvidia-smi 头部行形如
#      | NVIDIA-SMI 575.57.08   Driver Version: 575.57.08   CUDA Version: 12.9 |
#    其中同时含驱动版本号，必须“锚定 CUDA Version 关键字之后”再取版本，
#    否则会把驱动版本(575.57)误当成 CUDA 版本。
# =========================
CUDA_VER="unknown"

if command -v nvidia-smi >/dev/null 2>&1; then
    CUDA_LINE=$(nvidia-smi 2>/dev/null | grep -iE 'CUDA[[:space:]]*Version' | head -n1)
    if [[ $CUDA_LINE =~ [Cc][Uu][Dd][Aa][[:space:]]*[Vv]ersion[[:space:]]*:?[[:space:]]*([0-9]+)\.([0-9]+) ]]; then
        CUDA_VER="${BASH_REMATCH[1]}.${BASH_REMATCH[2]}"
    fi
fi

# nvidia-smi 不可用 / 解析失败时，回退到 nvcc（部分机器装了 toolkit）
if [[ "$CUDA_VER" == "unknown" ]] && command -v nvcc >/dev/null 2>&1; then
    NVCC_LINE=$(nvcc --version 2>/dev/null | grep -i release)
    if [[ $NVCC_LINE =~ release[[:space:]]+([0-9]+)\.([0-9]+) ]]; then
        CUDA_VER="${BASH_REMATCH[1]}.${BASH_REMATCH[2]}"
    fi
fi

# 取主版本号；非数字一律按 0（走默认兜底）
CUDA_MAJOR="${CUDA_VER%%.*}"
[[ "$CUDA_MAJOR" =~ ^[0-9]+$ ]] || CUDA_MAJOR=0
log "detected CUDA version: ${CUDA_VER} (major=${CUDA_MAJOR})"

# =========================
# 2. 按 CUDA 主版本选择 miner 二进制
#    nvidia-smi 报告的是“驱动最高支持”的 CUDA 版本：
#      驱动支持 CUDA13 → 可跑 cuda13/cuda12，优先 cuda13
#      驱动只到 CUDA12 → 只能跑 cuda12（cuda13 会因驱动过低启动失败）
#    选“主版本 <= 驱动支持版本”的最高可用二进制；选中的不存在时自动回退。
# =========================
pick_miner() {
    local major="$1" cand
    if [[ "$major" -ge 13 && -x ./miner-cuda13 ]]; then echo "./miner-cuda13"; return 0; fi
    if [[ "$major" -ge 11 && -x ./miner-cuda12 ]]; then echo "./miner-cuda12"; return 0; fi
    for cand in ./miner-cuda12 ./miner-cuda13 ./miner; do
        [[ -x "$cand" ]] && { echo "$cand"; return 0; }
    done
    return 1
}

MINER_BIN="$(pick_miner "$CUDA_MAJOR")" || die "no usable miner binary found in $(pwd)"


log "exec: $MINER_BIN"

## ───────────────────────────────────────────────
## 启动 miner
## 输出同时写入 HiveOS 标准日志（$CUSTOM_LOG_BASENAME.log），供 h-stats.sh 解析
## ───────────────────────────────────────────────
# --token 是可选项；TOKEN 为空时不传，避免传入空值导致 enrollment 失败
args=( --proxy "${CUSTOM_URL}" --address "${CUSTOM_TEMPLATE}" )
[[ -n "$TOKEN" ]] && args+=( --token "${TOKEN}" )
args+=( -gpu )

echo "Debug exec: $MINER_BIN ${args[*]}"

"$MINER_BIN" "${args[@]}" 2>&1 | tee -a "$CUSTOM_LOG_BASENAME.log"
