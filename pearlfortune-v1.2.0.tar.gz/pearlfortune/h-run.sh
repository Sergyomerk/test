#!/usr/bin/env bash
# set -euo pipefail

cd `dirname $0`

# 读取静态路径（CUSTOM_CONFIG_FILENAME / CUSTOM_LOG_BASENAME 等）
. h-manifest.conf

# 读取 h-config.sh 生成的配置（含飞行表里的 CUSTOM_URL / CUSTOM_TEMPLATE / CUSTOM_USER_CONFIG）
[[ -f $CUSTOM_CONFIG_FILENAME ]] && . $CUSTOM_CONFIG_FILENAME

# 解析 CUSTOM_USER_CONFIG（飞行表「其他参数」，可多行）：
#   - 形如 KEY=VALUE 的行 → 当环境变量 export（如 TOKEN / MINER_SUBMIT_VERSION），供 miner 子进程读取
#   - 其它行（如 --startup-bench）→ 收集为额外命令行参数，透传给 miner
# 不再对整段做 eval，避免把 flag 当命令执行而报 "command not found"
EXTRA_ARGS=()
while IFS= read -r _line; do
    _line="${_line#"${_line%%[![:space:]]*}"}"   # 去掉行首空白
    _line="${_line%"${_line##*[![:space:]]}"}"     # 去掉行尾空白
    [[ -z "$_line" || "$_line" == \#* ]] && continue
    if [[ "$_line" != -* && "$_line" =~ ^[A-Za-z_][A-Za-z0-9_]*= ]]; then
        set -a; eval "$_line"; set +a            # KEY=VALUE → export（eval 处理引号，如 TOKEN="..."）
    else
        eval "EXTRA_ARGS+=( $_line )"            # CLI flag → 透传（eval 拆词并尊重引号）
    fi
done <<< "$CUSTOM_USER_CONFIG"

log() { printf '[%(%F %T)T] [select-miner] %s\n' -1 "$*" >&2; }
die() { log "ERROR: $*"; exit 1; }

echo "Debug CUSTOM_URL=$CUSTOM_URL CUSTOM_TEMPLATE=$CUSTOM_TEMPLATE TOKEN=$TOKEN MINER_SUBMIT_VERSION=$MINER_SUBMIT_VERSION"
echo "Debug MINER_SUBMIT_VERSION=$MINER_SUBMIT_VERSION"

# ## ───────────────────────────────────────────────
# ## 按 GPU 型号选 miner 二进制
# ## 检测失败一律 fallback 到 ./miner，不阻断启动
# ## ───────────────────────────────────────────────
# MINER_BIN=./miner   # 安全默认
#
# if ! command -v nvidia-smi >/dev/null 2>&1; then
#     log "WARN: nvidia-smi not found; using default miner"
# elif ! gpu_names="$(timeout 5 nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null)" \
#      || [ -z "$gpu_names" ]; then
#     log "WARN: nvidia-smi query failed or 0 GPUs (driver/掉卡?); using default miner"
# else
#     gpu_count=$(printf '%s\n' "$gpu_names" | grep -c .)
#     five090_count=$(printf '%s\n' "$gpu_names" | grep -ic '5090' || true)
#     five4060_count=$(printf '%s\n' "$gpu_names" | grep -ic '4060' || true)
#     log "detected ${gpu_count} GPU(s): $(printf '%s\n' "$gpu_names" | paste -sd ';' -)"
#     # ## 给 5090 使用独立二进制
#     # if [ "$five090_count" -gt 0 ]; then
#     #     [ "$five090_count" -eq "$gpu_count" ] \
#     #         || log "WARN: mixed GPUs (${five090_count}/${gpu_count} are 5090); using miner-5090"
#     #     MINER_BIN=./miner-5090
#     # fi
#
#     ## 给 4060 指定环境变量
#     if [ "$five4060_count" -gt 0 ]; then
#         export MINER_GPU_LARGE_SLOTS=1
#     fi
# fi

# =========================
# 1. 获取 CUDA 版本（优先 nvidia-smi）
# =========================
CUDA_VER="unknown"
if command -v nvidia-smi >/dev/null 2>&1; then
    CUDA_VER_RAW=$(nvidia-smi 2>/dev/null | grep -i "CUDA Version" | head -n 1)
    if [[ $CUDA_VER_RAW =~ ([0-9]+\.[0-9]+) ]]; then
        CUDA_VER="${BASH_REMATCH[1]}"
    fi
fi

MINER_BIN=""

# 规则（你可以按需要改）
CUDA_MAJOR=$(echo "$CUDA_VER" | cut -d. -f1)

if [[ "$CUDA_MAJOR" == "13" ]]; then
    MINER_BIN="./miner-cuda13"
elif [[ "$CUDA_MAJOR" == "12" ]]; then
    MINER_BIN="./miner-cuda12"
elif [[ "$CUDA_MAJOR" == "11" ]]; then
    MINER_BIN="./miner-cuda12"   # 兼容 fallback（很多 miner CUDA12 向下兼容）
else
    echo "[WARN] Unknown CUDA version, fallback to cuda12 miner"
    MINER_BIN="./miner-cuda12"
fi


log "exec: $MINER_BIN"

## ───────────────────────────────────────────────
## 启动 miner
## 输出同时写入 HiveOS 标准日志（$CUSTOM_LOG_BASENAME.log），供 h-stats.sh 解析
## ───────────────────────────────────────────────
# --token 是可选项；TOKEN 为空时不传，避免传入空值导致 enrollment 失败
args=( --proxy "${CUSTOM_URL}" --address "${CUSTOM_TEMPLATE}" )
[[ -n "$TOKEN" ]] && args+=( --token "${TOKEN}" )
args+=( -gpu )
# 透传飞行表「其他参数」里的额外 flag（如 --startup-bench）
[[ ${#EXTRA_ARGS[@]} -gt 0 ]] && args+=( "${EXTRA_ARGS[@]}" )

echo "Debug exec: $MINER_BIN ${args[*]}"

"$MINER_BIN" "${args[@]}" 2>&1 | tee -a "$CUSTOM_LOG_BASENAME.log"
